<div class="jquery">
	</div><!--/jquery-->   
    <div class="wrappercenter">
		<div class="span12">
			<div class="span13">
        	</div><!--/span13-->
  			<p class="columnheading">
        	Welcome to EazyMaths.com
        	</p> </p>
  			<p align="justify"class="columncontent">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been theindustry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.Contrary to popular belief,  
        	</p>
        	<p align="right" class="style3"><a href="#" target="_blank">Read more</a></p>
  		</div><!--/span12-->
		<div class="row" style="margin-left: auto; margin-right: auto; ">
			<div class="span4">
			<img src="images/ourBusiness.png" />
			<p align="center" class="subcolumnheading">Our Business</p>
				<p align="justify" class="subcolumncontent">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type
                </p>
        	</div><!--/span4-->
			<div class="span4">
			<img src="images/ourProduct.png" />
			<p align="center" class="subcolumnheading">Our Product</p>
				<p align="justify" class="subcolumncontent">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type </p>
            </div><!--/span4-->
			<div class="span4">
			<img src="images/news.png" />
			<p align="center" class="subcolumnheading">News &  Events</p>
			<marquee onmouseover="stop();" onmouseout="start();" scrollamount="1" scrolldelay="2" direction="up" height="160">
  			<p align="justify" class="subcolumncontent">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown
            <br />
            <br />
            <br />
Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown
  			</p>
  			</marquee> 
			</div><!--/span4-->
		</div><!--/row-->
  		<br />
        <br />